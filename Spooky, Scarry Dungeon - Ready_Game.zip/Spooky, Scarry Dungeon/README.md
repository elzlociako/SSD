# Spooky, Scarry Dungeon - THE GAME
## Ogólnie o grze
W mojej grze gracz wciela się w łucznika, którego zadaniem jest przedarcie się przez pokoje wypełnione przeciwnikami. 
Przeciwnicy w każdym pokoju różnią się od siebie statystykami (zdrowie, zadawane obrażenia). 
Gra polega na pozbyciu się wszystkich przeciwników, nie dając się zabić. Musimy pokonać wszystkich przeciwników, którzy znajdują się w
danym pokoju by móc prześć do nastepnego. W przeciwnym wypadku przejscie przez kolce spowoduje pojawienie się takiej liczby przeciwników
jaką zabiliśmy. (Kolce nie zadają obrażeń) 

Poruszamy się za pomocą WSAD, a strzelamy lewym przyciskiem myszy w miejsce, w które wycelujemy myszką.
## Biblioteki 
Użyłem bilioteki SFML w wersji 2.5.1.
## Zewnętrzne zasoby
* Tileset: https://0x72.itch.io/dungeontileset-ii. 
* Tekstury: https://superdark.itch.io/16x16-free-npc-pack. 
* Muzyka i dźwięki: https://freesound.org.




